from flask import Flask, render_template
from utils import load_candidates_from_json, get_candidate, get_candidate_by_name, get_candidates_by_skill

app = Flask(__name__)
@app.route('/')
def page_index():
    candidates = load_candidates_from_json()
    return render_template('list.html', candidates=candidates)


@app.route('/candidates/<int:id>')
def page_candidate(id):
    candidate = get_candidate(id)
    return render_template('card.html', candidate=candidate)
#
@app.route('/search/<candidate_name>')
def page_search(candidate_name):
    candidates = get_candidate_by_name(candidate_name)
    return render_template('search.html', candidates=candidates)
#     f'''
#     <!DOCTYPE html>
#      <html>
#       <head>
#        <meta charset="utf-8">
#        <title>Кандидаты</title>
#       </head>
#
#       <body bgcolor="#20B2AA">
#         <div>{get_candidate_by_name(candidate_name, candidates_base_path)}<div>
#       </body>
#     </html>'''
#
#
# @app.route('/skill/<skill_name>')
# def page_skill(skill_name):
#     return f'''
#     <!DOCTYPE html>
#      <html>
#       <head>
#        <meta charset="utf-8">
#        <title>Кандидаты</title>
#       </head>
#
#       <body bgcolor="#20B2AA">
#         <div>{get_candidates_by_skill(skill_name, candidates_base_path)}<div>
#       </body>
#     </html>'''
app.run()

